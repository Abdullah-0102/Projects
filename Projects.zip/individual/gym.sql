-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 14, 2022 at 10:01 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gym`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `username` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`username`, `date`, `status`) VALUES
('hasnat', '18/3/2021', 'P'),
('moiz', '18/3/2021', 'P'),
('hasan', '18/3/2021', 'P'),
('arham', '18/3/2021', 'P'),
('hasnat', '27/12/2021', 'P'),
('moiz', '27/12/2021', 'P'),
('hasan', '27/12/2021', 'A'),
('arham', '27/12/2021', 'P');

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE `shop` (
  `ID` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shop`
--

INSERT INTO `shop` (`ID`, `name`, `price`) VALUES
('3', 'High-waist legging', '2500/-'),
('4', 'Grip Gloves', '2200/-'),
('5', 'Echt Clothing', '2200/-'),
('6', 'Gymshark Sportswear', '2000/-'),
('1', 'Grid Hooded Windbreaker', '2200'),
('2', 'Glacier Bike Short', '1500'),
('7', 'Allbirds Active Wear', '3000/-'),
('8', 'Rhyderwear', '2800/-'),
('9', 'Boohoo wear', '1900/-'),
('10', 'Leorever', '2500/-');

-- --------------------------------------------------------

--
-- Table structure for table `trainee`
--

CREATE TABLE `trainee` (
  `ID` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `number` varchar(255) NOT NULL,
  `join_date` varchar(255) DEFAULT NULL,
  `privilege` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trainee`
--

INSERT INTO `trainee` (`ID`, `username`, `password`, `full_name`, `age`, `number`, `join_date`, `privilege`) VALUES
(1, 'hasnat', 'hasnat123', 'hasnat khan', 18, '03456787654', '18-3-2021', 'trainee'),
(2, 'moiz', 'moiz123', 'Moiz Khan', 18, '03546767898', '19-5-2021', 'trainee'),
(3, 'hasan', 'hasan123', 'Hasan Ali', 19, '03123443213', '4-9-2021', 'trainee'),
(4, 'arham', 'arham123', 'Arham Khan', 21, '03459876123', '12-10-2021', 'trainee');

-- --------------------------------------------------------

--
-- Table structure for table `trainer`
--

CREATE TABLE `trainer` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL,
  `privilege` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trainer`
--

INSERT INTO `trainer` (`username`, `password`, `full_name`, `number`, `experience`, `privilege`) VALUES
('rafay', 'rafay123', 'Abdul Raffay', '', '3', 'trainer'),
('ali', 'ali123', 'Ali Abbas', '', '2', 'trainer');

-- --------------------------------------------------------

--
-- Table structure for table `workout_supplements`
--

CREATE TABLE `workout_supplements` (
  `ID` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `workout_supplements`
--

INSERT INTO `workout_supplements` (`ID`, `name`, `price`) VALUES
('1', 'Combat', '5000/-'),
('10', 'GPN-Protein', '8000/-'),
('11', 'Dymatize-ISO100', '9500/-'),
('12', 'Kasein-Micellar', '8000/-'),
('2', 'Nutriobio', '5500/-'),
('3', 'Amino-Energy', '5500/-'),
('4', 'Grip Gloves', '2200/-'),
('5', 'No-Xplode', '7000/-'),
('6', 'Platinum-Whee Protein', '8000/-'),
('7', 'Vega-Sport', '6500/-'),
('8', 'Pre-Gro Max', '10,000/-'),
('9', 'Hunt Jacked doze', '9500/-');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `trainee`
--
ALTER TABLE `trainee`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `workout_supplements`
--
ALTER TABLE `workout_supplements`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `trainee`
--
ALTER TABLE `trainee`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
