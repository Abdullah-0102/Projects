import mysql.connector as mysql

#database
db = mysql.connect(host="localhost",user="root",password="",database="gym")
command_handler = db.cursor(buffered=True)                          # pass buffered so that we can run multiple queries without errors
admin = "abdullah"
admin_password = "abdullah123"

#Authentication of Trainer
def auth_trainer():
    print("")
    print("====== Trainer Login =======")
    print("")
    username = input(str("Username:"))
    password = input(str("Password:"))
    query_vals = (username,password)
    command_handler.execute("SELECT * FROM trainer WHERE username = %s AND password = %s AND privilege = 'trainer'",query_vals)
    if command_handler.rowcount <= 0:
        print("Login not recognized")
    else:
        print("Login Successful ! Welcome " + username)
        trainer_session()


#Authentication of Trainee
def auth_trainee():
    print("")
    print("====== Trainee Login =======")
    print("")
    username = input(str("Username:"))
    password = input(str("Password:"))
    query_vals = (username,password)
    command_handler.execute("SELECT * FROM trainee WHERE username = %s AND password = %s AND privilege = 'trainee'",query_vals)
    if command_handler.rowcount <= 0:
        print("Login not recognized")
    else:
        print("Login Successful ! Welcome " + username)
        trainee_session(username)

#After authentication of trainee
def trainee_session(username):
    while 1:
        print("")
        print("======== Trainee Menu ========")
        print("1. View Register")
        print("2. Workout Supplements")
        print("3. Shop")
        print("4. Logout")

        user_option = input(str("Option:"))
        if user_option == "1":
            username = (str(username),)
            command_handler.execute("SELECT username, date, status FROM attendance WHERE username = %s ", username)
            records = command_handler.fetchall()
            for record in records:
                print(record)
        
        elif user_option == "2":
            print("")
            print("Welcome to our Protein Supplements Section !")
            print("")
            command_handler.execute("SELECT * FROM workout_supplements")
            n = command_handler.fetchall()
            for row in n:
                print(format(row[0] + ". " + row[1],"<40") + "Price:"+ row[2])
            
            print("Choose which supplement do you need. ")
            user_option = input(str("Option:"))

            if user_option == "1":
                print("Thanks for buying! Your bill will be 5000/- pkr")
                command_handler.execute("DELETE FROM workout_supplements WHERE ID = '1'")
                db.commit()                                
            elif user_option == "2":
                print("Thanks for buying! Your bill will be 5500/- pkr")
                command_handler.execute("DELETE FROM workout_supplements WHERE ID = '2'")
                db.commit()  
            elif user_option == "3":
                print("Thanks for buying! Your bill will be 5500/- pkr")
                command_handler.execute("DELETE FROM workout_supplements WHERE ID = '3'")
                db.commit()
            elif user_option == "4":
                print("Thanks for buying! Your bill will be 2200/- pkr")
                command_handler.execute("DELETE FROM workout_supplements WHERE ID = '4'")
                db.commit()                                        
            elif user_option == "5":
                print("Thanks for buying! Your bill will be 7000/- pkr")
                command_handler.execute("DELETE FROM workout_supplements WHERE ID = '5'")
                db.commit()
            elif user_option == "6":
                print("Thanks for buying! Your bill will be 8000/- pkr")
                command_handler.execute("DELETE FROM workout_supplements WHERE ID = '6'")
                db.commit()   
            elif user_option == "7":
                print("Thanks for buying! Your bill will be 6500/- pkr")
                command_handler.execute("DELETE FROM workout_supplements WHERE ID = '7'")
                db.commit()              
            elif user_option == "8":
                print("Thanks for buying! Your bill will be 10,00/- pkr")
                command_handler.execute("DELETE FROM workout_supplements WHERE ID = '8'")
                db.commit()
            elif user_option == "9":
                print("Thanks for buying! Your bill will be 9500/- pkr")
                command_handler.execute("DELETE FROM workout_supplements WHERE ID = '9'")
                db.commit()              
            elif user_option == "10":
                print("Thanks for buying! Your bill will be 8000/- pkr")
                command_handler.execute("DELETE FROM workout_supplements WHERE ID = '10'")
                db.commit()              
            elif user_option == "11":
                print("Thanks for buying! Your bill will be 9500/- pkr")
                command_handler.execute("DELETE FROM workout_supplements WHERE ID = '11'")
                db.commit()              
            elif user_option == "12":
                print("Thanks for buying! Your bill will be 8000/- pkr")
                command_handler.execute("DELETE FROM workout_supplements WHERE ID = '12'")
                db.commit()                                                     
                       
        
        elif user_option =="3":
            print("")
            print("Welcome to our Workout Gear Shop")
            print("")
            command_handler.execute("SELECT * FROM shop")
            n = command_handler.fetchall()
            for row in n:
                print(format(row[0] +". " + row[1],"<40") + "Price:" + row[2])
            
           
            user_option = input(str("Option:"))

            if user_option == "1":
                print("Thanks for buying! Your bill will be 2200/- pkr")
                command_handler.execute("DELETE FROM shop WHERE ID = '1'")
                db.commmit()                                
            elif user_option == "2":
                print("Thanks for buying! Your bill will be 1500/- pkr")
                command_handler.execute("DELETE FROM shop WHERE ID = '2'")
                db.commit()              
            elif user_option == "3":
                print("Thanks for buying! Your bill will be 2500/- pkr")
                command_handler.execute("DELETE FROM shop WHERE ID = '3'")
                db.commit()
            elif user_option == "4":
                print("Thanks for buying! Your bill will be 2200/- pkr")
                command_handler.execute("DELETE FROM shop WHERE ID = '4'")
                db.commit()
            elif user_option == "5":
                print("Thanks for buying! Your bill will be 2200/- pkr")
                command_handler.execute("DELETE FROM shop WHERE ID = '5'")
                db.commit()
            elif user_option == "6":
                print("Thanks for buying! Your bill will be 2000/- pkr")
                command_handler.execute("DELETE FROM shop WHERE ID = '6'")
                db.commit()
            elif user_option == "7":
                print("Thanks for buying! Your bill will be 3000/- pkr")
                command_handler.execute("DELETE FROM shop WHERE ID = '7'")
                db.commit()
            elif user_option == "8":
                print("Thanks for buying! Your bill will be 2800/- pkr")
                command_handler.execute("DELETE FROM shop WHERE ID = '8'")
                db.commit()
            elif user_option == "9":
                print("Thanks for buying! Your bill will be 1900/- pkr")
                command_handler.execute("DELETE FROM shop WHERE ID = '9'")
                db.commit()
            elif user_option == "10":
                print("Thanks for buying! Your bill will be 2500/- pkr")
                command_handler.execute("DELETE FROM shop WHERE ID = '10'")
                db.commit()
            
            else:
                print("You entered an invalid option.")

        elif user_option == "4":
            print("You have logged out of this section")
            break


#After authentication of trainer
def trainer_session():
    while 1:
        print("\n Trainer Menu\n")
        print("1. Mark trainee presence")
        print("2. View trainee details")
        print("3. Logout")

        user_option = input(str("Option:"))
        if user_option == "1":
            print("")
            print("Mark trainee presence")
            command_handler.execute("SELECT username FROM trainee WHERE privilege = 'trainee'")
            records = command_handler.fetchall()
            date = input(str("Date: DD/MM/YYYY: "))

            for record in records:
                record = str(record).replace("'","")
                record = str(record).replace(",","")
                record = str(record).replace("(","")
                record = str(record).replace(")","")

                # Present | Absent 
                status = input(str("Status for " + str(record) + "\tP/A :"))
                query_vals = (str(record),date,status)
                command_handler.execute("INSERT INTO attendance (username, date, status) VALUES (%s,%s,%s)",query_vals)
                db.commit()
                print(record + " marked as " + status)
            print("Presence and Absense has been marked !")

        elif user_option == "2":
            print("")
            print("Viewing all trainee details")
            command_handler.execute("SELECT username, date, status FROM attendance")
            records = command_handler.fetchall()
            print("Displaying all trainee details.")
            for record in records:
                print(record)

        elif user_option == "3":
            print("You have logged out of this section.")
            break

        else:
            print("No valid option was selected.")

#Authentication of Admin
def auth_admin():
    print("")
    print("======== Admin Login =======")
    print("")
    username = input(str("Username:"))
    password = input(str("Password:"))
    if username == admin:
        if password == admin_password:
            admin_session()
        else:
            print("Incorrect Password !")
    else:
        print("Login details not recognized.")




#After Authentication of Admin
def admin_session():
    print("Login Successful , Welcome Admin.")
    while 1:
        print("")
        print("Admin Menu")
        print("1.Register New Trainee")
        print("2.Register New Trainer")
        print("3.Delete Existing Trainee")
        print("4.Delete Existing Trainer")
        print("5.Add items to shop")
        print("6.Add Supplements")
        print("7.Logout of Admin Menu")

        user_option = input(str("option:"))
        if user_option == "1":
            print("")
            print("Register new trainee")
            username = input(str("Username:"))
            password = input(str("Password:"))
            full_name  = input(str("Full Name:"))
            age = input(str("Age:"))
            number = input(str("Phone Number:"))
            join_date = input(str("Joining date:"))
            query_vals = (username,password,full_name,age,number,join_date)
            command_handler.execute("INSERT INTO trainee (username,password,full_name,age,number,join_date,privilege) VALUES (%s,%s,%s,%s,%s,%s,'trainee')",query_vals)
            db.commit()
            print(username + " has been registered as a trainee")
        elif user_option == "2":
            print("")
            print("Register new trainer")
            username = input(str("Username:"))
            password = input(str("Password:"))
            full_name  = input(str("Full Name:"))
            number = input(str("Phone Number:"))
            experience = input(str("Experience in years:"))
            query_vals = (username,password,full_name,number,experience)
            command_handler.execute("INSERT INTO trainer (username,password,full_name,number,experience,privilege) VALUES (%s,%s,%s,%s,%s,'trainer')",query_vals)
            db.commit()
            print(username + " has been registered as a trainer")
        elif user_option == "3":
            print("")
            print("Delete existing trainee")
            username = input(str("Trainee Username:"))
            query_vals = (username,"trainee")
            command_handler.execute("DELETE FROM trainee WHERE username = %s AND privilege = %s", query_vals)
            db.commit()
            if command_handler.rowcount < 1:
                print("User not Found")
            else:
                print(username + " has been deleted")
        elif user_option == "4":
            print("")
            print("Delete existing trainer")
            username = input(str("Trainer Username:"))
            query_vals = (username,"trainer")
            command_handler.execute("DELETE FROM trainer WHERE username = %s AND privilege = %s", query_vals)
            db.commit()
            if command_handler.rowcount < 1:
                print("User not Found")
            else:
                print(username + " has been deleted")
        elif user_option == "5":
            print("")
            print("Add items to shop")
            ID = input(str("ID:"))
            name = input(str("Name:"))
            price  = input(str("Price:"))
            query_vals = (ID, name, price)
            command_handler.execute("INSERT INTO shop (ID,name,price) VALUES (%s,%s,%s)",query_vals)
            db.commit()
            print(name + " has been added as a new item in stock.")
        elif user_option == "6":
            print("")
            print("Add new protein supplement")
            ID = input(str("ID:"))
            name = input(str("Name:"))
            price  = input(str("Price:"))
            query_vals = (ID, name, price)
            command_handler.execute("INSERT INTO workout_supplements (ID,name,price) VALUES (%s,%s,%s)",query_vals)
            db.commit()
            print(name + " has been added as a new protein supplement in stock.")
        elif user_option == "7":
            print("You have logged out as an Admin")
            break
        else:
            print("No Valid option entered.")

def main():
    while 1:
        print("===================== Welcome to Sweat Spot Gym =======================")
        print("")
        print("1.Login as Trainee")
        print("2.Login as Trainer")
        print("3.Login as admin")

        user_option = input(str("Option:"))
        if user_option == "1":
            auth_trainee()
        elif user_option == "2":
            auth_trainer()
        elif user_option == "3":
            auth_admin()
        else:
            print("No valid entry was made !")
main()